The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

This is a copy of the changelog for the most recent version. For the full version history, go [here](https://github.com/illusivesoulworks/comforts/blob/1.21.x/CHANGELOG.md).

## [10.0.1+1.21.4] - 2025.05.30
### Fixed
- Fixed outdated bundled Cardinal Components API [#177](https://github.com/illusivesoulworks/comforts/issues/177)
